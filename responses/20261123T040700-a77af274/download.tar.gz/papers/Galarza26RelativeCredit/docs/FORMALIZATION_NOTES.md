# Notas de la formalización

La fuente es el [PDF fusionado](https://github.com/fgalarzac/ai-project/blob/3f32cbabf92da2ff82efd14961b8cb378a831c8c/paper/paper.pdf), del 10 de noviembre de 2026. Su SHA256 es `3918275f8a89f4e3eee13c3f4d018b90555fa15e796dcf70df466dbd104f31d3`. Las secciones matemáticas conservan el mismo texto LaTeX que la primera versión usada para construir las pruebas.

En [PaperInterface.lean](../PaperInterface.lean) se leen los tres enunciados completos. [ProofInterface.lean](../ProofInterface.lean) contiene las demostraciones de tipo exacto. El [informe](../FINAL_VALIDATION_REPORT.md) explica qué se comprueba y qué depende de los supuestos del paper. El [diagrama](DependencyDAG.pdf) muestra las relaciones entre los resultados y sus condiciones.

La evaluación es una elección condicionada en el precio. El ratio de cartera se interpreta para el mismo evento y horizonte de ambas cohortes, bajo S5. La formalización no aporta una estimación con datos bancarios ni una demostración de precios de equilibrio. Las anotaciones humanas del paquete de revisión no se han completado.

Los registros de aceptación se emiten por el motor sobre los archivos exactos; estas notas son una guía de lectura.
