import subprocess
p='Galarza26RelativeCredit'
commands=[['python3','scripts/sync_paper_status.py','--paper',p],['latexmk','-pdf','-interaction=nonstopmode','-halt-on-error','-cd','papers/'+p+'/docs/DependencyDAG.tex'],['python3','scripts/review_dashboard_packet.py','--paper',p,'--prepare-lean-cache'],['python3','scripts/review_dashboard_packet.py','--paper',p,'--write','--compile']]
for c in commands:subprocess.run(c,check=True)
