<!-- BEGIN GENERATED PAPER FOLDER README -->
# El precio relativo del crédito como señal de morosidad: evaluación óptima, restricciones y composición de la cartera

| Field | Value |
|---|---|
| Final status | Not started |
| Paper reference | El precio relativo del crédito como señal de morosidad: evaluación óptima, restricciones y composición de la cartera by Fabián Matías Galarza Chumbe; Publication details not listed. |
| Lines of Code | 138 |

## Key Links

- Final validation report: not tracked in this folder.
- Dependency DAG: not tracked in this folder.
- Compact Lean interface: [PaperInterface.lean](PaperInterface.lean)
- Source/status JSON: [status.json](status.json).
- Additional documentation: [FORMALIZATION_NOTES.md](docs/FORMALIZATION_NOTES.md)
<!-- END GENERATED PAPER FOLDER README -->
