"""Install optional report tools alongside proof work; records actual result."""
from pathlib import Path
import json
import os
import subprocess
import sys

here = Path(__file__).resolve().parent
result_path = here / 'tex_install_result.json'
pid_path = here / 'tex_install.pid'
if '--child' in sys.argv:
    result = subprocess.run(['sudo', 'apt-get', '-y', '-qq', 'install',
                             'latexmk', 'texlive-xetex', 'texlive-fonts-recommended'])
    result_path.write_text(json.dumps({'exit_code': result.returncode})+'\n')
    sys.exit(result.returncode)
if result_path.exists():
    print(result_path.read_text())
elif pid_path.exists():
    pid = int(pid_path.read_text())
    os.kill(pid, 0)
    print(json.dumps({'already_running_pid': pid}))
else:
    with (here / 'tex_install.log').open('w') as log:
        process = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), '--child'],
                                   stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    pid_path.write_text(str(process.pid))
    print(json.dumps({'started_pid': process.pid, 'log': str(here/'tex_install.log')}))
