from pathlib import Path
import hashlib,json,subprocess
p=Path("papers/Galarza26RelativeCredit")
assert hashlib.sha256((p/"source.pdf").read_bytes()).hexdigest()=="381af6e7d069af85faca6774b3c07e0f927fced227c284c41cf9b203ac81f4a5"
subprocess.run(["pdftotext",str(p/"source.pdf"),str(p/"source.txt")],check=True)
b=(p/"source.txt").read_bytes();t=b.decode()
print(json.dumps({"text_sha256":hashlib.sha256(b).hexdigest(),"lines":len(t.split("\n")),"pages":t.count("\f"),"text_extraction":{"tool":"pdftotext","options":[],"platform":"Linux","status":"extracted_once"}},indent=2))
