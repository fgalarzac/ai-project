import Galarza26RelativeCredit.Calculus
open Set Filter Topology
#check uniqueDiffWithinAt_Ici
#check uniqueDiffWithinAt_Iic
#check HasDerivWithinAt.unique
#check Ioi_mem_nhds
#check Iio_mem_nhds
#check mem_of_superset
#check HasDerivAt.hasDerivWithinAt
