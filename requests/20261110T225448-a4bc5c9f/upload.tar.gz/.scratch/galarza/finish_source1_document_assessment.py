"""Document review of the displayed three Exact rows, using engine-owned pins."""
from pathlib import Path
import json

from scripts.current_closeout.planner import current_document_semantic_basis_sha256
from scripts.final_validation_report_sections import section_four_result_table
from scripts.report_memo_coverage import coverage_template

paper=Path('papers/Galarza26RelativeCredit').resolve()
path=paper/'docs/REPORT_MEMO_COVERAGE.json'
prior=json.loads(path.read_text())
assert not prior['items']
assessment=coverage_template(paper)
table=assessment['result_table']
rows,errors=section_four_result_table((paper/'FINAL_VALIDATION_REPORT.md').read_text())
assert not errors and len(rows)==3,errors
if prior['report_inventory_complete']:
    assert set(prior['result_table']['rows'])=={row.sha256 for row in rows}
labels=[('proposition_1_global_solution_regimes','Proposición 1'),
        ('proposition_2_conditional_threshold','Proposición 2'),
        ('proposition_3_transmission_composition','Proposición 3')]
assert set(table['results'])=={key for key,_ in labels}
assert not assessment['items'], 'Each material memo item would need substantive review'
# Verified visually on PDF pp. 5, 6, and 7. The result rows are separate;
# Section 19 accounts for each distinct conclusion, including P1 ties and
# P3's exponential iff. No result introduces a correction or extra premise.
for row,(key,label) in zip(rows,labels,strict=True):
    assert row.result.startswith(label+' — ') and row.comparison=='**Exact**',row
    table['results'][key].update(numbering='numbered',printed_label=label,
        printed_label_basis='reviewed_rendered_source',
        row_mappings=[{'report_label':label,'row_sha256':row.sha256}])
    table['rows'][row.sha256]={'explanation_keys':[]}
table['complete']=True
assessment['report_inventory_complete']=True
digest=current_document_semantic_basis_sha256(paper)
assert isinstance(digest,str) and len(digest)==64
assessment['all_selected_semantic_review_sha256']=digest
path.write_text(json.dumps(assessment,ensure_ascii=False,indent=2)+'\n')
print('Document assessment complete for three visually numbered exact results:',digest)
