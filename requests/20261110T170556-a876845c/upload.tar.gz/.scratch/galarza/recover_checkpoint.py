"""Reestablish real git history and force the paper endpoint build after recovery."""
import subprocess,sys
if subprocess.check_output(['git','rev-parse','--is-shallow-repository'],text=True).strip()=='true':
    subprocess.run(['git','fetch','--unshallow','origin'],check=True)
sys.exit(subprocess.run(['lake','build','+Galarza26RelativeCredit.ProofInterface']).returncode)
