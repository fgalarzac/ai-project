import subprocess,sys
result=subprocess.run(['lake','build','+Galarza26RelativeCredit.ProofInterface'])
if result.returncode:
    sys.exit(result.returncode)
sys.exit(subprocess.run(['lake','env','lean','.scratch/galarza/CheckAxioms.lean']).returncode)
