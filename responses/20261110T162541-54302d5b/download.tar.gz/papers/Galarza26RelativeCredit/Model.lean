import Mathlib.Analysis.Calculus.Deriv.Mul
import Mathlib.Analysis.Calculus.Deriv.Inv
import Mathlib.Analysis.SpecialFunctions.ExpDeriv
import Mathlib.Topology.Order.IntermediateValue
import Mathlib.Tactic

/-!
Source model for the author-owned manuscript pinned at
https://github.com/fgalarzac/ai-project/blob/dc52cd19c3a53b4350c1cba1cf8b4a11037b95ad/paper/paper.pdf.
The price and technology are fixed before effort is chosen. There is no price
equilibrium assertion. All formulas below are transparent model primitives;
no record assumes optimality, a derivative formula, or a threshold.
-/

namespace Galarza26RelativeCredit

noncomputable section

/-- Prior credit-event fraction; paper S1. -/
def priorRisk (qbar a D : ℝ) : ℝ := qbar + a * D

/-- Performance premium; paper S3. -/
def premium (Rbar D : ℝ) : ℝ := Rbar + D

/-- Post-screening credit-event fraction; paper S2. -/
def screenedRisk (qbar a g D e : ℝ) : ℝ := priorRisk qbar a D - g * e

/-- The feasible effort interval from S2 and (5). -/
def feasibleEfforts (qbar a g E D : ℝ) : Set ℝ :=
  Set.Icc 0 (min E (priorRisk qbar a D / g))

/-- Expected profit per unit originated, for fixed price and primitives; (6). -/
def bankProfit (qbar a g c Rbar F D e : ℝ) : ℝ :=
  (1 - priorRisk qbar a D + g * e) * premium Rbar D - F - c * e ^ 2 / 2

/-- The closed-form effort candidate printed in P1. Optimality is proved separately. -/
def optimalEffort (qbar a g c Rbar E D : ℝ) : ℝ :=
  min (g * premium Rbar D / c) (min E (priorRisk qbar a D / g))

/-- The risk formula printed in P1. Its relation to optimized effort is proved. -/
def optimalRisk (qbar a g c Rbar E D : ℝ) : ℝ :=
  max 0 (priorRisk qbar a D - g * min E (g * premium Rbar D / c))

/-- Screening response strength, S4. -/
def screeningStrength (g c : ℝ) : ℝ := g ^ 2 / c

/-- Interior price slope, S4. -/
def interiorSlope (a g c : ℝ) : ℝ := a - g ^ 2 / c

/-- Deterministic/continuous-population exposure weight from S5. -/
def cohortWeight (B0 : ℝ) (B : ℝ → ℝ) (D : ℝ) : ℝ := B D / (B0 + B D)

/-- Expected impaired balance from the source's two-cohort ledger under S5. -/
def impairedBalance (B0 m0 : ℝ) (B q : ℝ → ℝ) (D : ℝ) : ℝ :=
  B0 * m0 + B D * q D

/-- Expected portfolio ratio: divide the impaired balance by deterministic total balance. -/
def portfolioRatio (B0 m0 : ℝ) (B q : ℝ → ℝ) (D : ℝ) : ℝ :=
  impairedBalance B0 m0 B q D / (B0 + B D)

/-- Price-sensitive origination family in P3. -/
def exponentialBalance (B1 epsilon D : ℝ) : ℝ := B1 * Real.exp (-epsilon * D)

end
end Galarza26RelativeCredit
