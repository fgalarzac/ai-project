from pathlib import Path
import subprocess

root=Path.cwd()
def run(*args):
    print('+',' '.join(args),flush=True)
    subprocess.run(args,check=True)
if subprocess.check_output(['git','rev-parse','--is-shallow-repository'],text=True).strip()=='true':
    run('git','fetch','--unshallow','origin')
run('git','pull','--ff-only','origin','main')
run('git','fetch','.scratch/editorial24/engine_registration.bundle','HEAD')
current=(root/'lakefile.toml').read_bytes()
registered=subprocess.check_output(['git','show','4d30604f45ddd6848fd87691c8e3ca63881b073b:lakefile.toml'])
upstream=subprocess.check_output(['git','show','194edcc95df74806a39b961d10dedddc6e730cce:lakefile.toml'])
if current != upstream:
    if current.replace(b'\r\n',b'\n') != registered.replace(b'\r\n',b'\n'):
        raise ValueError('Unexpected Lake configuration; do not overwrite it.')
    # The transport startup archive already carries this exact additive target.
    # Restore only the public tracked bytes before selecting its real commit.
    (root/'lakefile.toml').write_bytes(upstream)
run('git','checkout','--detach','4d30604f45ddd6848fd87691c8e3ca63881b073b')
info=root/'.git/info/attributes'
info.parent.mkdir(parents=True,exist_ok=True)
with info.open('a',encoding='utf-8') as handle:
    handle.write('\npapers/Galarza26RelativeCredit/** -text whitespace=cr-at-eol\n')
    handle.write('papers/Galarza26RelativeCredit.lean -text\n')
run('git','add','--','papers/Galarza26RelativeCredit','papers/Galarza26RelativeCredit.lean')
run('git','diff','--exit-code','194edcc95df74806a39b961d10dedddc6e730cce','--','scripts','config','skills','AppliedModelingLib')
run('python3','scripts/formalization_protocol.py')
run('python3','scripts/final_closure_receipt.py','--paper','Galarza26RelativeCredit','--check')
