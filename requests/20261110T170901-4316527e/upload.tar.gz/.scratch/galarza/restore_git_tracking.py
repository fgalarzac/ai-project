"""Restore tracked candidate inputs after archive-only workspace recovery.

This only stages the paper and Lake registration. It never changes engine
scripts, ignores, judgments or source bytes, and never forces ignored inputs.
The exact companion TeX is a local source cache, not a public contribution.
"""
import subprocess
subprocess.run(['git','add','--','lakefile.toml','papers/Galarza26RelativeCredit',
                ':(exclude)papers/Galarza26RelativeCredit/source.tex'],check=True)
subprocess.run(['git','diff','--cached','--stat'],check=True)
