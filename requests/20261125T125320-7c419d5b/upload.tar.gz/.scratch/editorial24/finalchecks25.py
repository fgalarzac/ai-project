from pathlib import Path
import json,subprocess,datetime
out=Path('.scratch/editorial24/finalchecks25');out.mkdir(exist_ok=True)
commands={'fast_check':['python3','scripts/paper_contribution.py','check','Galarza26RelativeCredit','--fast'],'full_module_checkpoint':['python3','scripts/private_paper_checkpoint.py','Galarza26RelativeCredit'],'receipt_final':['python3','scripts/final_closure_receipt.py','--paper','Galarza26RelativeCredit','--check'],'full_check':['python3','scripts/paper_contribution.py','check','Galarza26RelativeCredit'],'accepted_planner':['python3','scripts/closeout_reuse_plan.py','--paper','Galarza26RelativeCredit']}
results={}
for name,cmd in commands.items():
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (out/(name+'_stdout.txt')).open('wb') as stdout,(out/(name+'_stderr.txt')).open('wb') as stderr:result=subprocess.run(cmd,stdout=stdout,stderr=stderr)
 results[name]={'exit_code':result.returncode,'started_utc':start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 print(name,result.returncode,flush=True)
 if name!='full_check' and result.returncode:break
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
assert all(results.get(k,{}).get('exit_code')==0 for k in ['fast_check','full_module_checkpoint','receipt_final','accepted_planner']),results
