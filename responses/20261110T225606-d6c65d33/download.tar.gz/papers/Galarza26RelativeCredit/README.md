<!-- BEGIN GENERATED PAPER FOLDER README -->
# El precio relativo del crédito como señal de morosidad: evaluación óptima, restricciones y composición de la cartera

| Field | Value |
|---|---|
| Final status | Formalized |
| Paper reference | El precio relativo del crédito como señal de morosidad: evaluación óptima, restricciones y composición de la cartera by Fabián Matías Galarza Chumbe; Publication details not listed. |
| Lines of Code | 1,191 |

## Key Links

- Final validation report: [FINAL_VALIDATION_REPORT.md](FINAL_VALIDATION_REPORT.md)
- Dependency DAG: [DependencyDAG.pdf](docs/DependencyDAG.pdf)
- Human review packet: [HUMAN_REVIEW_PACKET.pdf](docs/HUMAN_REVIEW_PACKET.pdf)
- Compact Lean interface: [PaperInterface.lean](PaperInterface.lean)
- Source/status JSON: [status.json](status.json); [paper statement map](audit/paper_statement_map.json).
- Additional documentation: [FORMALIZATION_NOTES.md](docs/FORMALIZATION_NOTES.md)
<!-- END GENERATED PAPER FOLDER README -->
