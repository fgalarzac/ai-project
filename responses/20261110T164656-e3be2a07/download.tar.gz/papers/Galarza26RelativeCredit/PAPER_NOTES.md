# El precio relativo del crédito como señal de morosidad: evaluación óptima, restricciones y composición de la cartera Formalization Notes

This is a lightweight handoff document for source-to-Lean mapping.

- Namespace: `Galarza26RelativeCredit`
- Official URL: https://github.com/fgalarzac/ai-project/blob/dc52cd19c3a53b4350c1cba1cf8b4a11037b95ad/paper/paper.pdf
- Source PDF: `source.pdf`
- Local source text cache, if generated: `source.txt` (ignored by Git in public workspaces)

## Formalization checklist

- [ ] Full named-result inventory copied to the README theorem table.
- [ ] DAG graph includes all required paper-stage nodes and dependencies.
- [ ] README status and remaining-assumption notes match proof artifacts.
- [ ] Post-formalization library elevation pass completed: reusable proof
      results, techniques, and primitives were moved into `AppliedModelingLib` when
      local/low-risk, or recorded with destination modules in the final report.
- [ ] Recursive provenance is clear in the consolidated paper closeout. Run a
      standalone repository-wide provenance audit only for a named diagnostic
      failure or at an explicit integration/release boundary.
- [ ] Final status review completed before publishing.

## Notes

- Date reviewed:
- Last theorem row formalized:
- Outstanding assumptions / caveats:
- Reusable library elevation candidates:

