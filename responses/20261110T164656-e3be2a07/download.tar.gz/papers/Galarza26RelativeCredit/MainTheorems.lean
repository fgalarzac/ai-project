import Galarza26RelativeCredit.Optimization
import Galarza26RelativeCredit.Calculus
import Galarza26RelativeCredit.TieExample
import Galarza26RelativeCredit.Threshold
import Galarza26RelativeCredit.Stock

/-! Checked proof-support layer for the three paper endpoints. -/
